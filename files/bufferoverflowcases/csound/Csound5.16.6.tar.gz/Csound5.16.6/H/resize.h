typedef struct {
    OPDS h;
    MYFLT *size;                /* Ansser */
    MYFLT *fn;                  /* which table   */
    MYFLT *nsize;               /* new size */
} RESIZE;
