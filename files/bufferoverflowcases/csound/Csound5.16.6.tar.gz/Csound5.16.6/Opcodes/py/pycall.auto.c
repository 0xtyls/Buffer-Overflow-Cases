
static int pycall0_krate(CSOUND *csound, PYCALL0 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (result != Py_None)
      return errMsg(p, "callable must return None");

    Py_DECREF(result);
    return OK;
}

static int pylcall0_irate(CSOUND *csound, PYCALL0 *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall0_krate(CSOUND *csound, PYCALL0 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (result != Py_None)
      return errMsg(p, "callable must return None");

    Py_DECREF(result);
    return OK;
}

static int pylcall0i_irate(CSOUND *csound, PYCALL0 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    create_private_namespace_if_needed(&p->h);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (result != Py_None)
      return errMsg(p, "callable must return None");

    Py_DECREF(result);
    return OK;
}

static int pycall0t_krate(CSOUND *csound, PYCALL0T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (result != Py_None)
      return errMsg(p, "callable must return None");

    Py_DECREF(result);
    return OK;
}

static int pylcall0t_irate(CSOUND *csound, PYCALL0T *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall0t_krate(CSOUND *csound, PYCALL0T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (result != Py_None)
      return errMsg(p, "callable must return None");

    Py_DECREF(result);
    return OK;
}

static int pycall1_krate(CSOUND *csound, PYCALL1 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyFloat_Check(result)) {
      return errMsg(p, "callable must return a float");
    }
    else {
      *p->result = PyFloat_AsDouble(result);
    }
    return OK;

    Py_DECREF(result);
    return OK;
}

static int pylcall1_irate(CSOUND *csound, PYCALL1 *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall1_krate(CSOUND *csound, PYCALL1 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyFloat_Check(result)) {
      return errMsg(p, "callable must return a float");
    }
    else {
      *p->result = PyFloat_AsDouble(result);
    }
    return OK;

    Py_DECREF(result);
    return OK;
}

static int pylcall1i_irate(CSOUND *csound, PYCALL1 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    create_private_namespace_if_needed(&p->h);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyFloat_Check(result)) {
      return errMsg(p, "callable must return a float");
    }
    else {
      *p->result = PyFloat_AsDouble(result);
    }
    return OK;

    Py_DECREF(result);
    return OK;
}

static int pycall1t_krate(CSOUND *csound, PYCALL1T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result = p->oresult;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyFloat_Check(result)) {
      return errMsg(p, "callable must return a float");
    }
    else {
      *p->result = PyFloat_AsDouble(result);
      p->oresult = *p->result;
    }
    return OK;

    Py_DECREF(result);
    return OK;
}

static int pylcall1t_irate(CSOUND *csound, PYCALL1T *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall1t_krate(CSOUND *csound, PYCALL1T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result = p->oresult;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyFloat_Check(result)) {
      return errMsg(p, "callable must return a float");
    }
    else {
      *p->result = PyFloat_AsDouble(result);
      p->oresult = *p->result;
    }
    return OK;

    Py_DECREF(result);
    return OK;
}

static int pycall2_krate(CSOUND *csound, PYCALL2 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 2) {
      return errMsg(p, "callable must return 2 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall2_irate(CSOUND *csound, PYCALL2 *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall2_krate(CSOUND *csound, PYCALL2 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 2) {
      return errMsg(p, "callable must return 2 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall2i_irate(CSOUND *csound, PYCALL2 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    create_private_namespace_if_needed(&p->h);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 2) {
      return errMsg(p, "callable must return 2 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
    }

    Py_DECREF(result);
    return OK;
}

static int pycall2t_krate(CSOUND *csound, PYCALL2T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 2) {
      return errMsg(p, "callable must return 2 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall2t_irate(CSOUND *csound, PYCALL2T *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall2t_krate(CSOUND *csound, PYCALL2T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 2) {
      return errMsg(p, "callable must return 2 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
    }

    Py_DECREF(result);
    return OK;
}

static int pycall3_krate(CSOUND *csound, PYCALL3 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 3) {
      return errMsg(p, "callable must return 3 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall3_irate(CSOUND *csound, PYCALL3 *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall3_krate(CSOUND *csound, PYCALL3 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 3) {
      return errMsg(p, "callable must return 3 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall3i_irate(CSOUND *csound, PYCALL3 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    create_private_namespace_if_needed(&p->h);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 3) {
      return errMsg(p, "callable must return 3 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
    }

    Py_DECREF(result);
    return OK;
}

static int pycall3t_krate(CSOUND *csound, PYCALL3T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 3) {
      return errMsg(p, "callable must return 3 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall3t_irate(CSOUND *csound, PYCALL3T *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall3t_krate(CSOUND *csound, PYCALL3T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 3) {
      return errMsg(p, "callable must return 3 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
    }

    Py_DECREF(result);
    return OK;
}

static int pycall4_krate(CSOUND *csound, PYCALL4 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 4) {
      return errMsg(p, "callable must return 4 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall4_irate(CSOUND *csound, PYCALL4 *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall4_krate(CSOUND *csound, PYCALL4 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 4) {
      return errMsg(p, "callable must return 4 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall4i_irate(CSOUND *csound, PYCALL4 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    create_private_namespace_if_needed(&p->h);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 4) {
      return errMsg(p, "callable must return 4 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
    }

    Py_DECREF(result);
    return OK;
}

static int pycall4t_krate(CSOUND *csound, PYCALL4T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      *p->result4 = p->oresult4;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 4) {
      return errMsg(p, "callable must return 4 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      p->oresult4 = *p->result4;
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall4t_irate(CSOUND *csound, PYCALL4T *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall4t_krate(CSOUND *csound, PYCALL4T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      *p->result4 = p->oresult4;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 4) {
      return errMsg(p, "callable must return 4 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      p->oresult4 = *p->result4;
    }

    Py_DECREF(result);
    return OK;
}

static int pycall5_krate(CSOUND *csound, PYCALL5 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 5) {
      return errMsg(p, "callable must return 5 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall5_irate(CSOUND *csound, PYCALL5 *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall5_krate(CSOUND *csound, PYCALL5 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 5) {
      return errMsg(p, "callable must return 5 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall5i_irate(CSOUND *csound, PYCALL5 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    create_private_namespace_if_needed(&p->h);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 5) {
      return errMsg(p, "callable must return 5 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
    }

    Py_DECREF(result);
    return OK;
}

static int pycall5t_krate(CSOUND *csound, PYCALL5T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      *p->result4 = p->oresult4;
      *p->result5 = p->oresult5;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 5) {
      return errMsg(p, "callable must return 5 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      p->oresult4 = *p->result4;
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      p->oresult5 = *p->result5;
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall5t_irate(CSOUND *csound, PYCALL5T *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall5t_krate(CSOUND *csound, PYCALL5T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      *p->result4 = p->oresult4;
      *p->result5 = p->oresult5;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 5) {
      return errMsg(p, "callable must return 5 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      p->oresult4 = *p->result4;
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      p->oresult5 = *p->result5;
    }

    Py_DECREF(result);
    return OK;
}

static int pycall6_krate(CSOUND *csound, PYCALL6 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 6) {
      return errMsg(p, "callable must return 6 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall6_irate(CSOUND *csound, PYCALL6 *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall6_krate(CSOUND *csound, PYCALL6 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 6) {
      return errMsg(p, "callable must return 6 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall6i_irate(CSOUND *csound, PYCALL6 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    create_private_namespace_if_needed(&p->h);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 6) {
      return errMsg(p, "callable must return 6 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
    }

    Py_DECREF(result);
    return OK;
}

static int pycall6t_krate(CSOUND *csound, PYCALL6T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      *p->result4 = p->oresult4;
      *p->result5 = p->oresult5;
      *p->result6 = p->oresult6;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 6) {
      return errMsg(p, "callable must return 6 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      p->oresult4 = *p->result4;
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      p->oresult5 = *p->result5;
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      p->oresult6 = *p->result6;
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall6t_irate(CSOUND *csound, PYCALL6T *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall6t_krate(CSOUND *csound, PYCALL6T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      *p->result4 = p->oresult4;
      *p->result5 = p->oresult5;
      *p->result6 = p->oresult6;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 6) {
      return errMsg(p, "callable must return 6 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      p->oresult4 = *p->result4;
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      p->oresult5 = *p->result5;
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      p->oresult6 = *p->result6;
    }

    Py_DECREF(result);
    return OK;
}

static int pycall7_krate(CSOUND *csound, PYCALL7 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 7) {
      return errMsg(p, "callable must return 7 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      *p->result7 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 6));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall7_irate(CSOUND *csound, PYCALL7 *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall7_krate(CSOUND *csound, PYCALL7 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 7) {
      return errMsg(p, "callable must return 7 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      *p->result7 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 6));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall7i_irate(CSOUND *csound, PYCALL7 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    create_private_namespace_if_needed(&p->h);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 7) {
      return errMsg(p, "callable must return 7 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      *p->result7 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 6));
    }

    Py_DECREF(result);
    return OK;
}

static int pycall7t_krate(CSOUND *csound, PYCALL7T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      *p->result4 = p->oresult4;
      *p->result5 = p->oresult5;
      *p->result6 = p->oresult6;
      *p->result7 = p->oresult7;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 7) {
      return errMsg(p, "callable must return 7 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      p->oresult4 = *p->result4;
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      p->oresult5 = *p->result5;
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      p->oresult6 = *p->result6;
      *p->result7 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 6));
      p->oresult7 = *p->result7;
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall7t_irate(CSOUND *csound, PYCALL7T *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall7t_krate(CSOUND *csound, PYCALL7T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      *p->result4 = p->oresult4;
      *p->result5 = p->oresult5;
      *p->result6 = p->oresult6;
      *p->result7 = p->oresult7;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 7) {
      return errMsg(p, "callable must return 7 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      p->oresult4 = *p->result4;
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      p->oresult5 = *p->result5;
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      p->oresult6 = *p->result6;
      *p->result7 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 6));
      p->oresult7 = *p->result7;
    }

    Py_DECREF(result);
    return OK;
}

static int pycall8_krate(CSOUND *csound, PYCALL8 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 8) {
      return errMsg(p, "callable must return 8 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      *p->result7 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 6));
      *p->result8 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 7));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall8_irate(CSOUND *csound, PYCALL8 *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall8_krate(CSOUND *csound, PYCALL8 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 8) {
      return errMsg(p, "callable must return 8 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      *p->result7 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 6));
      *p->result8 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 7));
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall8i_irate(CSOUND *csound, PYCALL8 *p)
{
    char      command[1024];
    PyObject  *result;

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 1);

    create_private_namespace_if_needed(&p->h);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 8) {
      return errMsg(p, "callable must return 8 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      *p->result7 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 6));
      *p->result8 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 7));
    }

    Py_DECREF(result);
    return OK;
}

static int pycall8t_krate(CSOUND *csound, PYCALL8T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      *p->result4 = p->oresult4;
      *p->result5 = p->oresult5;
      *p->result6 = p->oresult6;
      *p->result7 = p->oresult7;
      *p->result8 = p->oresult8;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, 0);

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 8) {
      return errMsg(p, "callable must return 8 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      p->oresult4 = *p->result4;
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      p->oresult5 = *p->result5;
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      p->oresult6 = *p->result6;
      *p->result7 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 6));
      p->oresult7 = *p->result7;
      *p->result8 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 7));
      p->oresult8 = *p->result8;
    }

    Py_DECREF(result);
    return OK;
}

static int pylcall8t_irate(CSOUND *csound, PYCALL8T *p)
{
    create_private_namespace_if_needed(&p->h);
    return OK;
}

static int pylcall8t_krate(CSOUND *csound, PYCALL8T *p)
{
    char      command[1024];
    PyObject  *result;

    if (!*p->trigger) {
      *p->result1 = p->oresult1;
      *p->result2 = p->oresult2;
      *p->result3 = p->oresult3;
      *p->result4 = p->oresult4;
      *p->result5 = p->oresult5;
      *p->result6 = p->oresult6;
      *p->result7 = p->oresult7;
      *p->result8 = p->oresult8;
      return OK;
    }

    format_call_statement(command, (char*) p->function,
                          p->INOCOUNT, p->args, 2);

    result = eval_string_in_given_context(command, GETPYLOCAL(p->h.insdshead));

    if (result == NULL)
      return pyErrMsg(p, "python exception");

    if (!PyTuple_Check(result) || PyTuple_Size(result) != 8) {
      return errMsg(p, "callable must return 8 values");
    }
    else {
      *p->result1 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 0));
      p->oresult1 = *p->result1;
      *p->result2 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 1));
      p->oresult2 = *p->result2;
      *p->result3 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 2));
      p->oresult3 = *p->result3;
      *p->result4 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 3));
      p->oresult4 = *p->result4;
      *p->result5 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 4));
      p->oresult5 = *p->result5;
      *p->result6 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 5));
      p->oresult6 = *p->result6;
      *p->result7 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 6));
      p->oresult7 = *p->result7;
      *p->result8 = PyFloat_AsDouble(PyTuple_GET_ITEM(result, 7));
      p->oresult8 = *p->result8;
    }

    Py_DECREF(result);
    return OK;
}

