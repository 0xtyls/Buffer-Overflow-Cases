print 'zi'
