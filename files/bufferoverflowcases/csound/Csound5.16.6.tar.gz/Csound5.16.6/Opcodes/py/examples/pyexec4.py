print message
