print 'zum'
