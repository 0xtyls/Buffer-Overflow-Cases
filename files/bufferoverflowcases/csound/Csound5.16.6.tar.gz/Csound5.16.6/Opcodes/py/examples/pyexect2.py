print 'pa'
