message = 'a private random number: %f' % random.random()
