print 'zut'
