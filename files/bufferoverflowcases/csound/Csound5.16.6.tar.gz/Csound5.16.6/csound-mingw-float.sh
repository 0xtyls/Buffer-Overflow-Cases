#!/bin/sh

export PATH=/u/Mega-Nerd/libsndfile:${PATH}
export PATH=/u/fltk-mingw/src:${PATH}
export PATH=/u/portaudio:${PATH}
export PATH=/u/portmidi:${PATH}
export PATH=/u/Tcl/bin:${PATH}
export PATH=/u/swigwin-1.3.39:${PATH}
export PATH=/u/pd/bin:${PATH}
export PATH=/u/liblo:${PATH}
export PATH=/u/Java/jdk1.6.0_14/bin:${PATH}
export PATH=/u/fluidsynth.patched/src/.libs:${PATH}
export PATH=/u/Lua5.1:${PATH}
export PATH=/d/utah/home/mkg/projects/csoundf:${PATH}
export PATH=${PATH}:/d/utah/usr/bin
export PATH=${PATH}:/u/ATT/Graphviz/bin
export PATH=${PATH}:/u/MiKTeX-2.5/miktex/bin
export PATH=${PATH}:/u/doxygen/bin
export PATH=${PATH}:/u/ImageMagick-6.0.5-Q16
export PATH=${PATH}:/u/Python26
export PATH=${PATH}:/u/Python26/Scripts
export RAWWAVE_PATH=/d/utah/home/mkg/csoundf/Opcodes/stk/rawwaves
export OPCODEDIR=/d/utah/home/mkg/csoundf
export PYTHONPATH=/d/utah/home/mkg/csoundf


