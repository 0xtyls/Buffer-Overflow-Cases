#!/bin/sh
strip *.dll*
strip *.exe
strip *.pyd
