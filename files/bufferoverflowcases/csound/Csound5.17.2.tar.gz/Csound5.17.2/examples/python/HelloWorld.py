# Demonstrates the usual - how to get some sort of output out of the program.

print "Hello, world!"

