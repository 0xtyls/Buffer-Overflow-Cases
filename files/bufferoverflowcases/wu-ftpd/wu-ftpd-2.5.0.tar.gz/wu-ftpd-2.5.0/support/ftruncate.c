/*
 * $Id: ftruncate.c,v 1.3 1999/02/26 16:07:47 sob RELEASE sob $
 * Using chsize on systems that support it (XENIX and SVR4)
 * SPECIAL NOTE: On Xenix and SVR4, using this call in the BSD library
 * will REQUIRE the use of -lx for the extended library since chsize()
 * is not in the standard C library.
 *
 */

#include <fcntl.h> /* not always required */

ftruncate(fd,length)
    int fd;                     /* File descriptor for file that to change */
    off_t length;               /* New size for this file */
{
    int status;                 /* Status returned from chsize() proc */

    status = chsize(fd,length);
    return(status);
}

