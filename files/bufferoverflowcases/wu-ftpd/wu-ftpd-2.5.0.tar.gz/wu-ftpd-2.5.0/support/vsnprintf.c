/*
 * vsnprintf hack 
 * better than raw vsprintf, but only just barely....
 * $Id: vsnprintf.c,v 1.7 1999/02/26 16:07:47 sob RELEASE sob $
 */
#include <stdio.h>
#include <varargs.h>
int
#ifdef __STDC__
vsnprintf(char *str, size_t size, const char *format, va_list ap)
#else
vsnprintf(buf, bufsize, fmt, ap)
	char *buf;
	int bufsize;
	char *fmt;
	va_list ap;
#endif
{
	char *str;
	int status;
	if (bufsize < 1)
	  return(EOF);
	/* we need to verify that the actual length of the buf is greater than
           or equal to the bufsize argument */
        if ((str = (char *)calloc(bufsize+1))!= NULL){
	  strncpy(str,buf,bufsize);
	  status = vsprintf(str, fmt, ap);  
	  strcpy(buf,str);
	  free(str);
	}else
	  status = vsprintf(buf, fmt, ap);
        return status;
}
