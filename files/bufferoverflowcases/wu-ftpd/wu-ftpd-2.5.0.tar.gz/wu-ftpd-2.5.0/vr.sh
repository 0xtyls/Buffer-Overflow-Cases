REV=2.5.0

PATCH=../wu-ftpd-$REV.patch
cat /dev/null > $PATCH
for ORIG in `find * -name '*.orig'`; do
  NEW=`expr $ORIG : '\(.*\)\.'`
  echo diff -c $ORIG $NEW >> $PATCH
  diff -c $ORIG $NEW >> $PATCH
done
