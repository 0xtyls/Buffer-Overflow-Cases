### InspIRCd

InspIRCd is an IRC daemon written entirely from scratch, it is one of the  
few IRC daemons to be written in C++ and it was released under the GNU  
General Public License. InspIRCd is the second most used IRC daemon  
according to the ranking on SearchIRC.  

The first stable release of InspIRCd was in 2002.

### Links

Website: http://www.inspircd.org  
GitHub: https://github.com/inspircd/inspircd  