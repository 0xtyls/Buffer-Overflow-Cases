#!/bin/sh
echo "InspIRCd-2.0.5"
