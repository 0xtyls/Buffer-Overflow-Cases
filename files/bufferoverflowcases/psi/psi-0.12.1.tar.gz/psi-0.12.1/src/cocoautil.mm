#include <AppKit/AppKit.h>

#include "cocoautil.h"

void CocoaUtil::initialize()
{
	NSApplicationLoad();
}
