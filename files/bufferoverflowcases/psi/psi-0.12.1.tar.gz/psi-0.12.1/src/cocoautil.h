#ifndef COCOAUTIL_H
#define COCOAUTIL_H

namespace CocoaUtil 
{
	void initialize();
};

#endif
