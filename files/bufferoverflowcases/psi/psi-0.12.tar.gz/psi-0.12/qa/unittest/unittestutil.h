#ifndef UNITTESTUTIL_H
#define UNITTESTUTIL_H

#include <QDomElement>

namespace UnitTestUtil
{
	QDomElement createElement(const QString&);
};

#endif
