

/* MOPRC commands, the ones we use anyway */
#define MOPRC_CMD_RESERVE      0x0D
#define MOPRC_CMD_RELEASE      0x0F
#define MOPRC_CMD_REQUESTID    0x05
#define MOPRC_CMD_BOOT         0x06
#define MOPRC_CMD_SYSTEMID     0x07
#define MOPRC_CMD_COMMANDPOLL  0x11
#define MOPRC_CMD_RESPONSE     0x13
