/* functions and variables exported by manpath.c */
void prmanpath (void);
void init_manpath (void);

extern char ** mandirlist;
