extern void man_getopt (int argc, char **argv);

extern int global_apropos;
extern int alt_system;
extern char *alt_system_name;
extern char *opt_manpath;
