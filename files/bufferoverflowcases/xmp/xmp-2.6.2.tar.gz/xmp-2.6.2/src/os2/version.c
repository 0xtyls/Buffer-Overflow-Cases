char *xmp_version = "2.2.1"; 	char *xmp_date = "Wed Feb 23 09:14:49 BRST 2000"; 	char *xmp_build= "Compiled by Kevin Langman (langman@earthling.net) on " __DATE__ " at " __TIME__;
