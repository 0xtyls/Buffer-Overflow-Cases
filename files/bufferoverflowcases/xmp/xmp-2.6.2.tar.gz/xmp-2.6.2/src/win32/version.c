char *xmp_version = "2.6.2";
char *xmp_date = "Tue Jun 30 13:06:27 BRT 2009";
char *xmp_build = 0;
