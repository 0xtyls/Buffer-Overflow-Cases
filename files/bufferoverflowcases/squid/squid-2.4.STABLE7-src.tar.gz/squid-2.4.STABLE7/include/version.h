/*
 * $Id: version.h,v 1.131.2.9 2002/07/02 15:49:48 wessels Exp $
 *
 *  SQUID_VERSION - String for version id of this distribution
 */
#ifndef SQUID_VERSION
#define SQUID_VERSION	"2.4.STABLE7"
#endif

#ifndef SQUID_RELEASE_TIME
#define SQUID_RELEASE_TIME 1025625722
#endif
