/*
 * $Id: version.h,v 1.131.2.8 2002/03/19 23:52:12 wessels Exp $
 *
 *  SQUID_VERSION - String for version id of this distribution
 */
#ifndef SQUID_VERSION
#define SQUID_VERSION	"2.4.STABLE6"
#endif

#ifndef SQUID_RELEASE_TIME
#define SQUID_RELEASE_TIME 1016582072
#endif
