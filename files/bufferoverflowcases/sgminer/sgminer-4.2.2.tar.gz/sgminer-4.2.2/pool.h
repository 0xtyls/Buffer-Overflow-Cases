#ifndef POOL_H
#define POOL_H

#include "miner.h"

extern char* get_pool_name(struct pool *pool);
extern char* get_pool_user(struct pool *pool);

#endif /* POOL_H */
