#!/bin/sh -e
./configure
make
