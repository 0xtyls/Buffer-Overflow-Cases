#ifndef ETTERCAP_VERS_H
#define ETTERCAP_VERS_H

#define EC_VERSION            "0.8.2"
#define EC_VERSION_MAJOR      0
#define EC_VERSION_MINOR      8
#define EC_VERSION_REVISION   2
#define EC_PROGRAM            "ettercap"
#define EC_COPYRIGHT          "2001-2015"
#define EC_AUTHORS            "Ettercap Development Team"

#endif

/* EOF */

