#ifndef EC_API_EXTERN
#error Move this header somewhere else
#endif

EC_API_EXTERN int inet_aton(const char *cp, struct in_addr *);

/* EOF */

