#ifndef ETTERCAP_UPDATE_H
#define ETTERCAP_UPDATE_H

EC_API_EXTERN void global_update(void);

#endif

/* EOF */

// vim:ts=3:expandtab

