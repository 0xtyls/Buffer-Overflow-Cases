#include "timespec.h"
int futimens (int, char const *, struct timespec const [2]);
int utimens (char const *, struct timespec const [2]);
